# frozen_string_literal: true
require 'rubygems/source'
require 'rubygems/source_local'

# TODO warn upon require, this file is deprecated.

