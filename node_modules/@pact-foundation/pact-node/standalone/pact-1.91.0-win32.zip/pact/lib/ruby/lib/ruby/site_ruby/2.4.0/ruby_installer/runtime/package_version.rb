module RubyInstaller
module Runtime
PACKAGE_VERSION = "2.4.10-1"
GIT_COMMIT = "eb60b1c"
end
end
