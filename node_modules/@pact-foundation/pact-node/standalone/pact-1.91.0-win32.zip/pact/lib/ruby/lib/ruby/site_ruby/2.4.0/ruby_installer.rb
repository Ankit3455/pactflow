module RubyInstaller
  autoload :Runtime, 'ruby_installer/runtime'
end
